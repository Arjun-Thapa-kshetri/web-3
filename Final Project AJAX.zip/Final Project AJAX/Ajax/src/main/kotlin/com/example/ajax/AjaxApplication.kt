package com.example.ajax

//name: LIMBU TANKARAJ
//student ID: M22W7199

//name: Prashant kanwar
//student ID: M22W0379

//name: Arjun Thapa
//student ID: M22W0385

import org.springframework.boot.autoconfigure.SpringBootApplication
import org.springframework.boot.runApplication

@SpringBootApplication
class AjaxApplication

fun main(args: Array<String>) {
	runApplication<AjaxApplication>(*args)
}
