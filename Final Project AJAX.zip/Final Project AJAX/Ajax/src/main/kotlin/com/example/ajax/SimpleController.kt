package com.example.ajax

//name: LIMBU TANKARAJ
//student ID: M22W7199

//name: Prashant kanwar
//student ID: M22W0379

//name: Arjun Thapa
//student ID: M22W0385

import org.springframework.stereotype.Controller
import org.springframework.web.bind.annotation.PostMapping
import org.springframework.web.bind.annotation.RequestBody
import org.springframework.web.bind.annotation.RequestMapping
import org.springframework.web.bind.annotation.ResponseBody


@Controller
class SimpleController {

    @RequestMapping("/index")
    fun index(): String {
        return "index"
    }

    @PostMapping("/submitExtendedForm")
    @ResponseBody
    fun submitExtendedForm(@RequestBody formData: FormData): String {
        return "Name: ${formData.name}, Email: ${formData.email}, " +
                "Interests: ${formData.interests.joinToString(", ")}, Gender: ${formData.gender}, " + "Message: ${formData.message}"

    }

    data class FormData(
        val name: String,
        val email: String,
        val message: String,
        val gender: String,
        val interests: List<String>
    )

}

