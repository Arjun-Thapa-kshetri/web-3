package com.example.mqtt

//name: LIMBU TANKARAJ
//student ID: M22W7199

//name: Prashant kanwar
//student ID: M22W0379

//name: Arjun Thapa
//student ID: M22W0385

import org.springframework.web.bind.annotation.GetMapping
import org.springframework.web.bind.annotation.RequestParam
import org.springframework.web.bind.annotation.RestController

@RestController
class MqttController(private val mqttService: MqttService) {

    @GetMapping("/api/send-message")
    fun sendMessage(@RequestParam message: String): Map<String, String> {
        val result = mqttService.sendMessage(message)
        return mapOf("status" to result)
    }

    @GetMapping("/api/received")
    fun receivedMessage(): Map<String, String> {
        val receivedMessage = mqttService.getReceivedMessage()
        return mapOf("message" to receivedMessage)
    }
}


