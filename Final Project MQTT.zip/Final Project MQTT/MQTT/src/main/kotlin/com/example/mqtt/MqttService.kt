package com.example.mqtt

//name: LIMBU TANKARAJ
//student ID: M22W7199

//name: Prashant kanwar
//student ID: M22W0379

//name: Arjun Thapa
//student ID: M22W0385

import org.springframework.stereotype.Service

@Service
class MqttService {

    private var receivedMessage: String? = null

    fun sendMessage(message: String): String {
        receivedMessage = message
        return "Message sent successfully: $message"
    }

    fun getReceivedMessage(): String {
        // Return the received message
        return receivedMessage ?: "No message received yet"
    }
}

