package com.example.mqtt

import org.junit.jupiter.api.Test
import org.springframework.boot.test.context.SpringBootTest

@SpringBootTest
class MqttApplicationTests {

    @Test
    fun contextLoads() {
    }

}
