package com.example.newnext


data class User(
    var firstName: String = "",
    var lastName: String = ""
)
