package com.example.newnext


import org.springframework.stereotype.Controller
import org.springframework.ui.Model
import org.springframework.web.bind.annotation.GetMapping
import org.springframework.web.bind.annotation.PostMapping

@Controller
class UserController {

    @GetMapping("/user-form")
    fun userForm(model: Model): String {
        model.addAttribute("user", User())
        return "user-form"
    }

    @PostMapping("/submit-user")
    fun submitUser(user: User, model: Model): String {
        model.addAttribute("message", "User submitted: $user")
        return "confirmation"
    }
}
