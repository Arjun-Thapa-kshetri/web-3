import React, { useState } from 'react';

const UserForm = () => {
    const [user, setUser] = useState({ firstName: '', lastName: '' });

    const handleChange = (e) => {
        setUser({ ...user, [e.target.name]: e.target.value });
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        const response = await fetch('/submit-user', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(user),
        });
        const result = await response.json();
        console.log(result);
    };

    return (
        <div>
            <h2>User Form</h2>
            <form onSubmit={handleSubmit}>
                <label htmlFor="firstName">First Name:</label>
                <input type="text" id="firstName" name="firstName" value={user.firstName} onChange={handleChange} required /><br />

                <label htmlFor="lastName">Last Name:</label>
                <input type="text" id="lastName" name="lastName" value={user.lastName} onChange={handleChange} required /><br />

                <button type="submit">Submit</button>
            </form>
        </div>
    );
};

