package com.example.newnext

import org.junit.jupiter.api.Test
import org.springframework.boot.test.context.SpringBootTest

@SpringBootTest
class NewNextApplicationTests {

    @Test
    fun contextLoads() {
    }

}
