package com.example.websockets

//name: LIMBU TANKARAJ
//student ID: M22W7199

//name: Prashant kanwar
//student ID: M22W0379

//name: Arjun Thapa
//student ID: M22W0385


import org.springframework.context.annotation.Configuration
import org.springframework.web.socket.config.annotation.EnableWebSocket
import org.springframework.web.socket.config.annotation.WebSocketConfigurer
import org.springframework.web.socket.config.annotation.WebSocketHandlerRegistry

@Configuration
@EnableWebSocket
class SocketConfig : WebSocketConfigurer {
    override fun registerWebSocketHandlers(registry: WebSocketHandlerRegistry) {
        registry.addHandler(TextHandler(), "/chat")
            .setAllowedOrigins("*")
    }
}



