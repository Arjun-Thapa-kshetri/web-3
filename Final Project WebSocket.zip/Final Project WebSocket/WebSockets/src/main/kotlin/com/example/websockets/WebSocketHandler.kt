package com.example.websockets


//name: LIMBU TANKARAJ
//student ID: M22W7199

//name: Prashant kanwar
//student ID: M22W0379

//name: Arjun Thapa
//student ID: M22W0385

import org.springframework.web.socket.TextMessage
import org.springframework.web.socket.WebSocketSession
import org.springframework.web.socket.handler.TextWebSocketHandler

class TextHandler : TextWebSocketHandler() {
    override fun handleTextMessage(session: WebSocketSession, message: TextMessage) {
        val payload = message.payload
        val response = "Server: Received message - $payload"
        session.sendMessage(TextMessage(response))
    }
}

