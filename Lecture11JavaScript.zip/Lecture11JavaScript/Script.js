//Initialize cart and total
let cart =[];
let total = 0;
//Function to add Items to the cart
function addToCart(productName, price){
    cart.push({productName, price});
    total += price;
    //Update the cart items and total on the page
    updateCart();
}
//Function to update the cart display on the page
function updateCart(){
    const cartItemsElement= document.getElementById('cartItems');
    const cartTotalElement =document.getElementById('cartTotal');

    //clear previous cart items
cartTotalElement.innerHTML='';
// Add current cart items
cart.forEach(item => {
    const listItem =document.createElement('l1');
    listItem.textContent=`${item.productName} - $${item.price}`;
    cartItemsElement.appendChild(listItem);
})

//Update total
cartTotalElement.textContent = total;
}
